NIGHTFALL — Android app project
===============================

This is a native Android Studio project. The game runs inside an offline
Android WebView packaged in the app. It does not need a website, browser,
account, or internet connection once installed.

IMPORTANT
This workspace cannot compile/sign an APK because the Android SDK and
Android build tools are not installed here. This ZIP is the complete
Android Studio project source, not an APK.

Build an installable APK
------------------------
1. Install Android Studio on a computer.
2. Open Android Studio and choose "Open".
3. Select the NightfallAndroid folder (the folder containing settings.gradle.kts).
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Usually:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer app-debug.apk to the Android phone and open it to install.
   If Android asks, allow installation from that file manager.

App details
-----------
Name: NIGHTFALL
Application ID: com.nightfall.partygame
Minimum Android: Android 6.0 (API 23)
Orientation: Portrait
Network permission: None
Game assets: app/src/main/assets/index.html

To create a release APK for distribution, use
Build > Generate Signed Bundle / APK in Android Studio.
